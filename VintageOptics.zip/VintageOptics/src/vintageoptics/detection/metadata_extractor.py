# src/vintageoptics/detection/metadata_extractor.py

class MetadataExtractor:
    """Comprehensive metadata extraction from images"""
    
    def __init__(self):
        self.exif_reader = ExifReader()
        self.maker_note_factory = MakerNoteParserFactory()
        self.raw_metadata_extractor = RawMetadataExtractor()
    
    def extract_all_metadata(self, image_path: str) -> ComprehensiveMetadata:
        """Extract all available metadata from image file"""
        
    def extract_electronic_lens_data(self, metadata: Dict) -> ElectronicLensData:
        """Extract electronic lens communication data"""
        
    def extract_shooting_conditions(self, metadata: Dict) -> ShootingConditions:
        """Extract environmental and camera state data"""
        
    def extract_applied_corrections(self, metadata: Dict) -> AppliedCorrections:
        """Detect in-camera or software corrections already applied"""
        
    def _parse_proprietary_data(self, maker: str, data: bytes) -> Dict:
        """Parse manufacturer-specific data blocks"""